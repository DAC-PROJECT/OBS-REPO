import React from "react";
const AboutPage = () => {
    return (
        <div className="container">
            <div className="py-4">
                <h1>AboutPage</h1>
                <p className="lead">The about us page is commonly used by all types of businesses to give customers more insight into who is involved with a given business and exactly what it does. The history of a business is often provided, and the histories of the people in charge are usually expressed through short articles, usually accompanied by photographs.
             Depending on the specific company, some information about goals, attitude or other aspects of culture that
              aren't strictly tied to business practices are included as well. The about us page is often a reflection 
              of the purpose and personality of the business and its owners or top employees. 
               Finally, the page can also incorporate contact or locational information.
              One way to view the about us concept is as a text self-portrait or short autobiography created by a business.

                </p>
                <p className="lead">The about us page is commonly used by all types of businesses to give customers more insight into who is involved with a given business and exactly what it does. The history of a business is often provided, and the histories of the people in charge are usually expressed through short articles, usually accompanied by photographs.
             Depending on the specific company, some information about goals, attitude or other aspects of culture that
              aren't strictly tied to business practices are included as well. The about us page is often a reflection 
              of the purpose and personality of the business and its owners or top employees. 
               Finally, the page can also incorporate contact or locational information.
              One way to view the about us concept is as a text self-portrait or short autobiography created by a business.

                </p>
                <p className="lead">The about us page is commonly used by all types of businesses to give customers more insight into who is involved with a given business and exactly what it does. The history of a business is often provided, and the histories of the people in charge are usually expressed through short articles, usually accompanied by photographs.
             Depending on the specific company, some information about goals, attitude or other aspects of culture that
              aren't strictly tied to business practices are included as well. The about us page is often a reflection 
              of the purpose and personality of the business and its owners or top employees. 
               Finally, the page can also incorporate contact or locational information.
              One way to view the about us concept is as a text self-portrait or short autobiography created by a business.

                </p>

            </div>
        </div>
    );
};
export default AboutPage;
import React from "react";
const ContactPage = () => {
    return (
        <div className="container">
            <div className="py-4">
            <div class="row">
  <div class="col">
    <input type="text" class="form-control" placeholder="First name" aria-label="First name"/>
  </div>
  <div class="col">
    <input type="text" class="form-control" placeholder="Last name" aria-label="Last name"/>
  </div>
</div>
<br></br>
<input class="btn btn-primary" type="submit" value="Submit"/>
<br></br>
<br/>
<input class="btn btn-primary" type="reset" value="Reset" ></input>
            </div>
        </div>
        
    );
};
export default ContactPage;
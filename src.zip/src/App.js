import React from "react";
import './App.css';
import "../node_modules/bootstrap/dist/css/bootstrap.css";
import Homepage from "./components/pages/Homepage";
import Contactpage from "./components/pages/ContactPage";
import AboutPage from "./components/pages/AboutPage";
import Navbar from "./components/Layout/Navbar";
import {BrowserRouter as Router,Route,Switch} from "react-router-dom";
function App() {
  return (
    <Router>
      <div className="App">
    
           <Navbar />
           <Switch>
             <Route exact path="/" component={Homepage}/>
             <Route exact path="/contactpage" component={Contactpage}/>
             <Route exact path="/aboutpage" component={AboutPage}/>
           </Switch>
         
        </div>
    </Router>
  );
}

export default App;

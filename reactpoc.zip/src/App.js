import logo from './logo.svg';
import ReactDOM from 'react-dom';
import React from 'react';
import './App.css';



const Product=[
{category:'Sporting Goods',Name:'FootBall',price:1200,Stocked:true},
{category:'Sporting Goods',Name:'BaseBall',price:5600,Stocked:false},
{category:'Sporting Goods',Name:'BasketBall',price:3865,Stocked:false},
{category:'Electronics',Name:'iPod Touch',price:58000,Stocked:true},
{category:'Electronics',Name:'iPhone 5',price:37500,Stocked:false},
{category:'Electronics',Name:'Nexus 7',price:55000,Stocked:true}];


class App extends React.Component{
  constructor(props){
    super(props);
    this.state={
          filterText:'',
          inStockOnly:false
    };
    this.handleFilterTextChange=this.handleFilterTextChange.bind(this);
    this.handleInStockChange=this.handleInStockChange.bind(this);
  }

  handleFilterTextChange(filterText){
      this.setState({
        filterText:filterText
      });
  }

  handleInStockChange(inStockOnly){
     this.setState({
       inStockOnly:inStockOnly
     });
  }

  render(){
      return(
        <div>
          <SearchBar filterText={this.state.filterText}
          inStockOnly={this.state.inStockOnly}
          onFilterTextChange={this.handleFilterTextChange}
          onInStockChange={this.handleInStockChange} ></SearchBar> 

          <ProductTable products={this.props.products}
          filterText={this.state.filterText}
          inStockOnly={this.state.inStockOnly } 
          ></ProductTable> 
        </div>
      );
  }
}

class SearchBar extends React.Component{
      constructor(props){
       super(props);
       this.handleFilterTextChange=this.handleFilterTextChange.bind(this);
       this.handleInStockChange=this.handleInStockChange.bind(this);
      }

      handleFilterTextChange(e){
        this.props.onFilterTextChange(e.target.value);
      }

      handleInStockChange(e){
        this.props.onInStockChange(e.target.checked);
      }

      render(){
        return(
          <form>
            <input type="text" placeholder="Search.." value={this.props.filterText} onChange={this.handleFilterTextChange}></input>
            <p>
              <input type="checkbox" checked={this.props.inStockOnly} onChange={this.handleInStockChange} ></input>
              {''}
              Only Show Products In Stock
            </p>
          </form>
        );
      }
}


class ProductTable extends React.Component{
      render(){
        const filterText=this.props.filterText;
        const inStockOnly=this.props.inStockOnly;
        const rows=[];
        let lastCategory=null;
        this.props.products.forEach(products=>{
          
        });
      }
}

class ProductCategoryRow extends React.Component{
        render(){
          const category=this.props.category;
          return(
            <tr>
              <th colSpan="2">
                {category}
              </th>
            </tr>
          );
        }
}

class ProductRow extends React.Component{

}

export default App;



















/*class App extends React.Component{
   constructor(props){
      super(props)
      this.state={
        data:''
      }
      this.updateState=this.updateState.bind(this);
      this.clearInput=this.clearInput.bind(this);
     };

     updateState(e){
       this.setState({
         data:e.target.value
       });
     }

     clearInput(){
       this.setState({
         data:''
       });
       ReactDOM.findDOMNode(this.refs.myInput).focus();
      }
        /*
         * using refs we are pointing to input element
         * after that we are making focus on element having 
         * specified keyword
        
      render(){
        return(
          <div>
            <input value={this.state.data} onChange={this.updateState} ref="myInput"></input>
         <button  onClick={this.clearInput} >CLEAR</button>
        <h4>{this.state.data}</h4>
          </div>
        );
      }
} 

export default App;*/


/* class App extends React.Component{
   constructor(props){
     super(props);
     this.state={
       data:'Initial data'  
     }
     this.updateState=this.updateState.bind(this);
   };

   updateState(){
       this.setState({
         data:'Data updated From Child Component'
       } );
   }

   render(){
     return(
        <div>
          <Content myProp={this.state.data} 
          updateStatProp={this.updateState}></Content>
        </div>
       
     );
   }
 }

 class Content extends React.Component{
   render(){
     return(
       <div>
         <button onClick={this.props.updateStatProp}>Click Me</button>
     <h3>{this.props.myProp}</h3>
       </div>
     );
   }
 }


export default App;*/



/*class Toggle extends React.Component{
  constructor(props){
    super(props);
    this.state={isToggleOn:true};
    this.handleClick=this.handleClick.bind(this);
  }

  handleClick(){
    this.setState(prvState=>({
      isToggleOn:!prvState.isToggleOn
    }));
  }

  render(){
    return(
    <button onClick={this.handleClick}>{this.isToggleOn?'ON':'OFF'}</button>
    );
  }
}*/


  /*class App extends React.Component{
    constructor(props){
    super(props);
    this.state={

    }
    this.updateState=this.updateState.bind(this);
  }
           render(){
             return(
               <div>Hello React</div>
             );
           }
  } */

  
/*function App() {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          Learn React
        </a>
      </header>
    </div>
  );
}*/

//export default App;

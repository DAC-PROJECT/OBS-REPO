const student=()=>{
    console.log('student is called')
      var name='piyush'
      //var y='rahul'  
      const sayName=()=>{
          console.log(name)
      }
      return sayName
}
console.log(student()) //delete 

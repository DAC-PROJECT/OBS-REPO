/*
 *  in this program when init function is called,it is returning reference of 
 *  sayName() ,which is using  var name.even though init() execution is completed 
 *  but total memory can not freed up because it is sending reference of sayName()
 *  when sayName () will be executed name var will be used so we can say name is closure
 * to the sayName()
*/

function init(){
    console.log('init executed')
    var name='piyush'
    function sayName(){
        console.log(name);
    }
    return sayName;
}

var gotFun=init();
console.dir(gotFun)
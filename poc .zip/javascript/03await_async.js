

const uno=()=>{
      return 'i am one'
}

const dos=async()=>{
    setTimeout(() => {
        return 'i am two'
    }, 5000);
}

const tres=()=>{
    return 'i am three'
}

const call=()=>{
    let val1=uno()
    console.log(val1)

    let val2=dos()
    console.log(val2)

    let val3=tres()
    console.log(val3)
}

call()





var x=()=>{
    console.log('hi i am x function ')
}

var y=(callback)=>{
    console.log('going to call callback function')
    callback()
}

y(x)
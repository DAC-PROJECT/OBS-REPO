console.log('person 1 :ticket')
console.log('person 2 :ticket')


const wifePromise=new Promise((resolve,reject)=>{
        setTimeout(() => {
             resolve('ticket')  
        }, 3000)
})


const husbandPromise=wifePromise.then((t)=>{
     console.log('husband:we should go in')
     console.log('wife : no i am hungry')
     return new Promise((resolve,reject)=>{resolve(t)})
})

husbandPromise.then((t)=>{
    console.log(`couple ticket : ${t}`)
})

console.log('person 4 :ticket')
console.log('person 5 :ticket')
import logo from './logo.svg';
import './App.css';
import React ,{Component} from 'react';
import Greet from './components/Greet';

function App() {
  return (
    <div className="App">
      <Greet name="Alia" heroname="Ranbeer" >
        <p>Hello guys</p></Greet>
      <Greet  name="Anushka" heroname="Virat">
        <p>Hello friends</p>
        </Greet>
      <Greet name="Aishwarya"  heroname="Abhishek">
        <p>Hello dear</p>
        </Greet>
    </div>
  );
}

export default App;
